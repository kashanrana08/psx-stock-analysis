PSX Stock Analysis Pro — Starter Kit
=====================================

یہ ابتدائی ویب ڈیش بورڈ پیکج ہے۔ اس میں:
- public/index.html : ویب ڈیش بورڈ
- public/psx_data_template.csv : روزانہ ڈیٹا امپورٹ کا CSV فارمیٹ

آن لائن مفت ہوسٹنگ (ابتدائی مرحلہ):
1) GitHub پر اکاؤنٹ بنائیں اور نیا repository بنائیں۔
2) اس ZIP کے اندر موجود فائلیں repository میں upload کریں۔
3) Cloudflare Pages میں GitHub repository کو connect کریں۔
4) Build command خالی چھوڑیں۔
5) Build output directory میں public لکھیں۔
6) Deploy کے بعد Cloudflare آپ کو *.pages.dev ویب لنک دے گا۔

اہم ڈیٹا اور قانونی نوٹ:
- اس ورژن میں خودکار PSX ڈیٹا فیڈ منسلک نہیں ہے۔
- PSX کے market data کو ویب سائٹ یا ایپ میں استعمال/دوبارہ دکھانے سے پہلے PSX سے تحریری اجازت یا متعلقہ لائسنس کی تصدیق کریں۔
- PSX Data Services رابطہ: marketdatarequest@psx.com.pk
- جب مجاز API/feed یا قابلِ استعمال EOD فائل ملے گی تو backend ingestion، database، اور scheduled refresh جوڑے جائیں گے۔
- ابھی CSV import صرف آپ کے فراہم کردہ ڈیٹا پر کام کرتا ہے؛ demo prices یا فرضی signals شامل نہیں۔

Cloudflare Pages کی موجودہ دستاویزات:
https://developers.cloudflare.com/pages/
PSX Data Services:
https://www.psx.com.pk/psx/product-and-services/data-services-vending

یہ سرمایہ کاری کا مشورہ نہیں۔ کسی بھی آرڈر سے پہلے قیمت، price limits، اور broker کی معلومات verify کریں۔
